from setuptools import find_packages, setup
from glob import glob
import os

package_name = 'navigator'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + package_name],
        ),

        (
            "share/" + package_name,
            ["package.xml"],
        ),

        (
            os.path.join(
                "share",
                package_name,
                "launch",
            ),
            glob("launch/*.launch.py"),
        ),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
                'baro = navigator.node_baro:main',
                'control = navigator.node_control:main',
                'fusion = navigator.node_fusion:main',
                'navigation = navigator.node_navigation:main',
                'navigator = navigator.node_navigator:main',
                'rc = navigator.node_rc:main',
                'cam = navigator.node_cam:main',
        ],
    },
)
